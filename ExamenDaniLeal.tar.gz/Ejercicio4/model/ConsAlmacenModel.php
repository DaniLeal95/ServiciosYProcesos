<?php

/**
 * Created by PhpStorm.
 * User: dleal
 * Date: 17/11/16
 * Time: 10:35
 */
namespace ConstantesDB;
class ConsAlmacenModel
{
    /*ALMACEN*/
    const TABLE_NAME = "almacen";
    const COD = "idproducto";
    const TIPO = "tipo";
    const CANTIDAD = "cantidad";

    /*DISTINTOS SUBTIPOS*/
    const TABLE_NAME_COMIDA = "alimentos";
    const TABLE_NAME_BEBIDA = "bebidas";
    const TABLE_NAME_SUMINISTRO = "suministros";
    const NOMBRE ="nombre";

}